
import asyncio


from PyQt5.QtWidgets import QMessageBox, QMainWindow, QWidget, QSplitter, QPushButton, QTextEdit, QSpacerItem, \
    QGroupBox, \
    QFormLayout, QSizePolicy, QFormLayout, QApplication, QLabel, QSpacerItem, QGridLayout, QLineEdit
from PyQt5.QtCore import Qt, QMetaObject, QCoreApplication
from PyQt5.QtGui import QPalette, QBrush, QColor, QFont
import yaml
import time
import psycopg2
import os

time.sleep(3)
class Ui_Setting_Network(object):

    def setupUi(self, Setting_Network):
        self.CURRENT_DIR = os.path.dirname(os.path.realpath(__file__))
        Setting_Network.setObjectName("Setting_Network")
        Setting_Network.resize(629, 567)
        font = QFont()
        font.setPointSize(9)
        font.setBold(True)
        font.setWeight(75)
        Setting_Network.setFont(font)
        self.gridLayout = QGridLayout(Setting_Network)
        self.gridLayout.setObjectName("gridLayout")
        self.groupBox_3 = QGroupBox(Setting_Network)
        self.groupBox_3.setAutoFillBackground(True)
        self.groupBox_3.setTitle("")
        self.groupBox_3.setObjectName("groupBox_3")
        self.formLayout = QFormLayout(self.groupBox_3)
        self.formLayout.setObjectName("formLayout")



        self.label_11 = QLabel(self.groupBox_3)
        self.label_11.setObjectName("label_11")
        self.formLayout.setWidget(0, QFormLayout.LabelRole, self.label_11)
        self.lineEdit_11 = QLineEdit(self.groupBox_3)
        self.lineEdit_11.setObjectName("lineEdit_11")
        self.formLayout.setWidget(0, QFormLayout.FieldRole, self.lineEdit_11)
        self.label_12 = QLabel(self.groupBox_3)
        self.label_12.setObjectName("label_12")
        self.formLayout.setWidget(1, QFormLayout.LabelRole, self.label_12)
        self.lineEdit_12 = QLineEdit(self.groupBox_3)
        self.lineEdit_12.setObjectName("lineEdit_12")
        self.formLayout.setWidget(1, QFormLayout.FieldRole, self.lineEdit_12)
        self.label_10 = QLabel(self.groupBox_3)
        self.label_10.setObjectName("label_10")
        self.formLayout.setWidget(2, QFormLayout.LabelRole, self.label_10)
        self.lineEdit_10 = QLineEdit(self.groupBox_3)
        self.lineEdit_10.setObjectName("lineEdit_10")
        self.formLayout.setWidget(2, QFormLayout.FieldRole, self.lineEdit_10)
        spacerItem = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)
        self.formLayout.setItem(4, QFormLayout.FieldRole, spacerItem)

        self.labelDatabasePort = QLabel(self.groupBox_3)
        self.labelDatabasePort.setObjectName("labelDatabasePort")
        self.formLayout.setWidget(5, QFormLayout.LabelRole, self.labelDatabasePort)
        self.labelDatabasePort.setText("Database Port")

        self.lineEditDatabasePort = QLineEdit(self.groupBox_3)
        self.lineEditDatabasePort.setObjectName("lineEditDatabasePort")
        self.formLayout.setWidget(5, QFormLayout.FieldRole, self.lineEditDatabasePort)


        self.label_14 = QLabel(self.groupBox_3)
        self.label_14.setObjectName("label_14")
        self.formLayout.setWidget(6, QFormLayout.LabelRole, self.label_14)
        self.lineEdit_14 = QLineEdit(self.groupBox_3)
        self.lineEdit_14.setObjectName("lineEdit_14")
        self.formLayout.setWidget(6, QFormLayout.FieldRole, self.lineEdit_14)
        self.label_15 = QLabel(self.groupBox_3)
        self.label_15.setObjectName("label_15")
        self.formLayout.setWidget(7, QFormLayout.LabelRole, self.label_15)
        self.lineEdit_15 = QLineEdit(self.groupBox_3)
        self.lineEdit_15.setObjectName("lineEdit_15")
        self.formLayout.setWidget(7, QFormLayout.FieldRole, self.lineEdit_15)

        self.labelVersion =  QLabel(self.groupBox_3)
        self.labelVersion.setObjectName("labelVersion")
        self.formLayout.setWidget(8, QFormLayout.LabelRole, self.labelVersion)
        self.labelVersion.setText("Station Number")



        self.lineEditStationNUmber = QLineEdit(self.groupBox_3)
        self.lineEditStationNUmber.setObjectName("lineEditStationNUmber")
        self.formLayout.setWidget(8, QFormLayout.FieldRole, self.lineEditStationNUmber)
        self.lineEditStationNUmber.setReadOnly(False)

        self.labelVersion = QLabel(self.groupBox_3)
        self.labelVersion.setObjectName("labelVersion")
        self.formLayout.setWidget(9, QFormLayout.LabelRole, self.labelVersion)
        self.labelVersion.setText("Version")

        self.linelabelVersionShow = QLabel(self.groupBox_3)
        self.linelabelVersionShow.setObjectName("linelabelVersionShow")
        self.formLayout.setWidget(9, QFormLayout.FieldRole, self.linelabelVersionShow)


        spacerItem1 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)
        self.formLayout.setItem(10, QFormLayout.FieldRole, spacerItem1)
        self.pushButton_10 = QPushButton(self.groupBox_3)

        self.pushButton_10.setObjectName("pushButton_10")
        self.formLayout.setWidget(11, QFormLayout.LabelRole, self.pushButton_10)
        self.pushButton_4 = QPushButton(self.groupBox_3)

        self.pushButton_4.setAutoFillBackground(True)
        self.pushButton_4.setObjectName("pushButton_4")
        self.formLayout.setWidget(11, QFormLayout.FieldRole, self.pushButton_4)
        self.lineEdit = QLineEdit(self.groupBox_3)
        self.lineEdit.setObjectName("lineEdit")
        self.formLayout.setWidget(3, QFormLayout.FieldRole, self.lineEdit)
        self.label = QLabel(self.groupBox_3)
        self.label.setObjectName("label")
        self.formLayout.setWidget(3, QFormLayout.LabelRole, self.label)
        self.gridLayout.addWidget(self.groupBox_3, 0, 0, 1, 1)
        spacerItem2 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem2, 0, 1, 1, 1)

        self.retranslateUi(Setting_Network)
        QMetaObject.connectSlotsByName(Setting_Network)
        Setting_Network.setTabOrder(self.lineEdit_11, self.lineEdit_12)
        Setting_Network.setTabOrder(self.lineEdit_12, self.lineEdit_10)
        Setting_Network.setTabOrder(self.lineEdit_10, self.lineEdit)
        Setting_Network.setTabOrder(self.lineEdit, self.lineEdit_14)
        Setting_Network.setTabOrder(self.lineEdit_14, self.lineEdit_15)
        Setting_Network.setTabOrder(self.lineEdit_15, self.pushButton_4)
        Setting_Network.setTabOrder(self.pushButton_4, self.pushButton_10)

        self.lineEdit_10.setEchoMode(QLineEdit.Password)

        self.pushButton_4.setStyleSheet(StylSheet(self))
        self.pushButton_10.setStyleSheet(StylSheet(self))
        self.pushButton_10.clicked.connect(self.Set_Defualt_Setting)
        self.pushButton_4.clicked.connect(self.test_contection)

    def retranslateUi(self, Setting_Network):
        _translate = QCoreApplication.translate
        Setting_Network.setWindowTitle(_translate("Setting_Network", "Form"))
        self.label_11.setText(_translate("Setting_Network", "DataBase Address"))
        self.label_12.setText(_translate("Setting_Network", "User"))
        self.label_10.setText(_translate("Setting_Network", "Password"))
        self.label_14.setText(_translate("Setting_Network", "Send port"))
        self.label_15.setText(_translate("Setting_Network", "Server Address"))
        self.pushButton_10.setText(_translate("Setting_Network", "Save"))
        self.pushButton_4.setText(_translate("Setting_Network", "تست ارتباط"))
        self.label.setText(_translate("Setting_Network", "DataBase"))
        try:
            with open(f"{self.CURRENT_DIR}/config.yaml", "r") as yamlfile:
                data_r = yaml.load(yamlfile, Loader=yaml.FullLoader)
            self.lineEdit_11.setText(data_r[0]['DATA_Setting']['DataBase_Address'])
            self.lineEdit_12.setText(data_r[0]['DATA_Setting']['USER_SERVER'])
            self.lineEdit_10.setText(data_r[0]['DATA_Setting']['PASSWORD_SERVER'])
            self.lineEdit.setText(data_r[0]['DATA_Setting']['DataBase_Name'])
            self.lineEdit_14.setText(data_r[0]['DATA_Setting']['send_port'])
            self.lineEdit_15.setText(data_r[0]['DATA_Setting']['Server_Address'])
            self.lineEditStationNUmber.setText(data_r[0]['DATA_Setting']['StationNumber'])
            self.lineEditDatabasePort.setText(data_r[0]['DATA_Setting']['DatabasePort'])
            self.linelabelVersionShow.setText(str(data_r[0]['DATA_Setting']['Version']))
            self.BarcodeRestart = str(data_r[0]['DATA_Setting']['BarcodeRestart'])
            self.BarcodeShutdown = str(data_r[0]['DATA_Setting']['BarcodeShutdown'])
            self.BarcodReader_ID = str(data_r[0]['DATA_Setting']['BarcodReader_ID'])
            self.BarcodeRepair = str(data_r[0]['DATA_Setting']['BarcodeRepair'])
            self.BarcodeProdocer = str(data_r[0]['DATA_Setting']['BarcodeProdocer'])
            self.BarcodReader_ID = str(data_r[0]['DATA_Setting']['BarcodReader_ID'])

        except:
            import sys
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Critical)
            msg.setText("ارتباط با دیتابیس  برقرار نشد  ")
            msg.setWindowTitle("No Conecction")
            msg.exec_()

    async  def Test_connection(self):
        await asyncio.sleep(0.9)



        try:
            with open(f"{self.CURRENT_DIR}/config.yaml", "r") as yamlfile:

                data_r = yaml.load(yamlfile, Loader=yaml.FullLoader)
            connection = psycopg2.connect(database=data_r[0]['DATA_Setting']['DataBase_Name'], user=data_r[0]['DATA_Setting']['USER_SERVER'], password=data_r[0]['DATA_Setting']['PASSWORD_SERVER'],
                                          host=data_r[0]['DATA_Setting']['DataBase_Address'], port="5432")

            Cursore = connection.cursor()

            #
            # DB_save = mysql.connector.connect(
            #     host=data_r[0]['DATA_Setting']['DataBase_Address'],
            #     user=data_r[0]['DATA_Setting']['USER_SERVER'],
            #     password=data_r[0]['DATA_Setting']['PASSWORD_SERVER'],
            #     database=data_r[0]['DATA_Setting']['DataBase_Name'],)
            # cursor = DB_save.cursor()
            # test =  cursor.execute("show TABLES;")

            # DB_save = mysql.connector.connect(
            #     host=data_r[0]['DATA_Setting']['DataBase_Address'],
            #     user=data_r[0]['DATA_Setting']['USER_SERVER'],
            #     password=data_r[0]['DATA_Setting']['PASSWORD_SERVER'],
            #     database=data_r[0]['DATA_Setting']['DataBase_Name'],)
            # cursor = DB_save.cursor()
            #


            msg = QMessageBox()
            # msg.setIcon(QMessageBox.)
            msg.setText("ارتباط با دیتابیس ردیابی  برقرار  شد  ")
            msg.setWindowTitle("Connection Success Full ")
            msg.exec_()
        except:

            msg_1 = QMessageBox()
            msg_1.setIcon(QMessageBox.Critical)
            # msg.setStyle('fusion')
            msg_1.setText("ارتباط با دیتابیس ردیابی  برقرار نشد")

            msg_1.setWindowTitle("No Conecction")
            msg_1.exec_()

    def Set_Defualt_Setting(self):
        msg_Q = QMessageBox()
        msg_Q.setIcon(QMessageBox.Information)
        msg_Q.setText("برای ذخیره  کردن اطلاعات   لطفا تایید کنید ")

        msg_Q.setWindowTitle("Save dialog")
        msg_Q.setDetailedText("مقادیری که در فرم میباشد ذخیره میشود")
        msg_Q.addButton(QMessageBox.Yes)
        msg_Q.addButton(QMessageBox.No)
        msg_Q.setDefaultButton(QMessageBox.Yes)
        return_value = msg_Q.exec_()
        if return_value == QMessageBox.Yes:
            Setting_data = [
                {

                    'DATA_Setting': {
                        'DataBase_Address': self.lineEdit_11.text(),
                        'USER_SERVER': self.lineEdit_12.text(),
                        'PASSWORD_SERVER': self.lineEdit_10.text(),
                        'DataBase_Name': self.lineEdit.text(),
                        'send_port': self.lineEdit_14.text(),
                        'Server_Address': self.lineEdit_15.text(),
                        'StationNumber': self.lineEditStationNUmber.text(),
                        'DatabasePort' : self.lineEditDatabasePort.text(),
                        'BarcodeRestart': self.BarcodeRestart,
                        'BarcodeShutdown': self.BarcodeShutdown,
                        'Version':  self.linelabelVersionShow.text(),
                         'BarcodeRepair':     self.BarcodeRepair,
                          'BarcodeProdocer':  self.BarcodeProdocer ,
                          'BarcodReader_ID':     self.BarcodReader_ID ,

                    }
                }
            ]

            with open(f"{self.CURRENT_DIR}/config.yaml", "w") as yamlfile_w:
                data_w = yaml.dump(Setting_data, yamlfile_w)
                
  

            # DataBase_Address = self.lineEdit_11.text()
            # USER_SERVER = self.lineEdit_12.text()
            # PASSWORD_SERVER = self.lineEdit_10.text()
            # DataBase_Name = self.lineEdit.text()
            # socket_port_send = self.lineEdit_14.text()
            # socket_port_recive = self.lineEdit_15.text()
            #
            # Setting_data = DataBase_Address, USER_SERVER, PASSWORD_SERVER, DataBase_Name, socket_port_send,  socket_port_recive
            # with open("system_Windows.txt", "w") as fileSettiong:
            #     fileSettiong.write(str("Seeting_DataBase\n"))
            #     for i in enumerate(Setting_data):
            #         fileSettiong.write(i[1] + "\n")


    def test_contection(self):
        asyncio.run(self.Test_connection())

def StylSheet(self):
    return """
                QGroupBox:hover
                {
                background-color: #94ffcd;
                }

                QPushButton:hover
                {
                background-color: gray;
                }

                QPushButton
                {
                background-color: red;
                }
                QLineEdit:hover
                 {
                background-color: #a9ffe0;
                }
                    QTableView
                {

                selection-background-color: #aaffd2;

                position: relative;
                }

                    QTextEdit
                {
                background-color: #bdffdb;

                }
                QTextEdit:hover
                {
                background-color: #aaffd2;
                height: 200px;
                width: 50%;
                border: 1px solid #03ffab;
                }


                """


if __name__ == "__main__":
    import sys

    app = QApplication(sys.argv)
    app.setStyle("fusion")
    Setting_Network = QWidget()
    ui = Ui_Setting_Network()
    ui.setupUi(Setting_Network)
    # ui.Set_Defualt_Setting()
    Setting_Network.show()
    sys.exit(app.exec_())
