import yaml
import os
import requests
import patoolib
import time

from numpy import double

time.sleep(8)
# from pyunpack import Archive
porotocol = "http://"
class AutoUpdate():
    def Setup(self):
        self.CURRENT_DIR = os.path.dirname(os.path.realpath(__file__))


    def ReadSetting(self):
        try:
            with open(f"{self.CURRENT_DIR}/config.yaml", "r") as yamlfile:
                self.data_r = yaml.load(yamlfile, Loader=yaml.FullLoader)

                self.send_port = self.data_r[0]['DATA_Setting']['send_port']
                self.Server_Address = self.data_r[0]['DATA_Setting']['Server_Address']
                self.DataBase_Name = self.data_r[0]['DATA_Setting']['DataBase_Name']
                self.USER_SERVER = self.data_r[0]['DATA_Setting']['USER_SERVER']
                self.PASSWORD_SERVER = self.data_r[0]['DATA_Setting']['PASSWORD_SERVER']
                self.DataBase_Address = self.data_r[0]['DATA_Setting']['DataBase_Address']
                self.StationNumber   = self.data_r[0]['DATA_Setting']['StationNumber']
                self.DatabasePort   = self.data_r[0]['DATA_Setting']['DatabasePort']
                self.ApplicationVersion = self.data_r[0]['DATA_Setting']['Version']
                self.BarcodeShutdown = self.data_r[0]['DATA_Setting']['BarcodeShutdown']
                self.BarcodeRestart = self.data_r[0]['DATA_Setting']['BarcodeRestart']
                self.BarcodeRepair = self.data_r[0]['DATA_Setting']['BarcodeRepair']
                self.BarcodeProdocer = self.data_r[0]['DATA_Setting']['BarcodeProdocer']





        except:
            print("ارتباط با دیتا بیس برقرار نشد ")

    def download_file(self, url):
        local_filename = url.split('/')[-1]
        # NOTE the stream=True parameter below
        with requests.get(url, stream=True) as r:
            r.raise_for_status()
            with open(local_filename, 'wb') as f:
                for chunk in r.iter_content(chunk_size=8192):
                    # If you have chunk encoded response uncomment if
                    # and set chunk_size parameter to None.
                    # if chunk:
                    f.write(chunk)
        return local_filename

    def GetUpdate(self):
        pass
        try:

            response = requests.get(f'{porotocol + self.Server_Address + ":" + self.send_port}/rest/list/ClientApp/')
            if response.status_code == 200:

                data = response.json()

                for i in reversed(range(len(data))):

            #
                    if data[i]['version'] > double(self.ApplicationVersion):

                        if data[i]['Active'] == True:
            #

                            AppUrl = data[i]['App']

                            AppFile = self.download_file(url=AppUrl)
                            patoolib.extract_archive(AppFile, outdir=self.CURRENT_DIR)
                            # Archive(AppFile).extractall(directory=self.CURRENT_DIR)
                            print("extracted")
            #                 # ########## Screensaver  disable
            #                 # file = open('/etc/lightdm/lightdm.conf', 'a')
            #                 # file.write('xserver-command=X -s 0 -p 0 -dpms')
            #                 # file.close()
                            Setting_data = [
                                {

                                    'DATA_Setting': {
                                        'DataBase_Address': data[i]['DataBase_Address'],
                                        'USER_SERVER':      data[i]['USER_SERVER'],
                                        'PASSWORD_SERVER':  data[i]['PASSWORD_SERVER'],
                                        'DataBase_Name':    data[i]['DataBase_Name'],
                                        'send_port':        data[i]['send_port'],
                                        'Server_Address':   data[i]['Server_Address'],
                                        'StationNumber':    self.StationNumber,
                                        'DatabasePort':     data[i]['DatabasePort'],
                                        'Version':          str(data[i]['version']),
                                        'BarcodeShutdown':  str(data[i]['BarcodeShutdown']),
                                        'BarcodeRestart':   str(data[i]['BarcodeRestart']),
                                        'BarcodeRepair':   str(data[i]['BarcodeRepair']),
                                        'BarcodeProdocer':   str(data[i]['BarcodeProdocer']),

                                    }
                                }
                            ]

                            with open(f"{self.CURRENT_DIR}/config.yaml", "w") as yamlfile_w:
                                data_w = yaml.dump(Setting_data, yamlfile_w)

                            os.system('python3.7 -m pip   install -r  requirements.txt')

                            time.sleep(3)
                            os.system(f'python3.7 {self.CURRENT_DIR}/ClientApp_07.py')
                    if data[i]['version'] == double(self.ApplicationVersion):
                        pass

                        os.system(f'python3.7 {self.CURRENT_DIR}/ClientApp_07.py')



            else:
                pass
                time.sleep(5)
                os.system(f'python3.7 {self.CURRENT_DIR}/ClientApp_07.py')

        except:
            time.sleep(5)
            os.system(f'python3.7 {self.CURRENT_DIR}/ClientApp_07.py')




if __name__ == "__main__":
    app = AutoUpdate()
    app.Setup()
    app.ReadSetting()
    app.GetUpdate()